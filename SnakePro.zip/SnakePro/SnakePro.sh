#!/bin/bash
java -Djava.library.path=natives-linux/ -jar SnakePro.jar
